description 'Slå NPC politi fra'

client_script 'ingenstjerner.lua'